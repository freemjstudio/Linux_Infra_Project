<?php
echo "Hello PHP!<br>";
phpinfo();
?>


